create function fun(eno in number) return number is
  FunctionResult number;
  psal emp.sal%type;
  pcomm emp.comm%type;
begin
  select sal,comm into psal,pcomm from emp where empno=eno;
  FunctionResult:=psal*12+nvl(pcomm,0);
  return(FunctionResult);
end fun;
/

