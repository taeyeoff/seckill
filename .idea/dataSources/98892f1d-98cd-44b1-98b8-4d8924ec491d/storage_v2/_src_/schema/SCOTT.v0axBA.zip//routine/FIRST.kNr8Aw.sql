create procedure first(par in number) is
psal emp.sal%type;
begin
  dbms_output.put_line('start');
  select sal into psal from emp where empno=par;
  update emp set sal=sal+100 where empno=par;
  dbms_output.put_line(psal||' now:'||(psal+100));
end first;
/

