create trigger CHECKSALARY
  before update
  on EMP
  for each row
  declare
  -- local variables here
begin
  if :new.sal<:old.sal then
    raise_application_error(-20002,'有误');
    end if;
end checkSalary;
/

