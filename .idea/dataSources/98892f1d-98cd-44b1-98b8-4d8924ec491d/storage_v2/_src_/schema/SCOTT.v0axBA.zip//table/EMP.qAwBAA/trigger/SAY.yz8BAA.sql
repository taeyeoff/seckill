create trigger SAY
  after insert
  on EMP
  declare
  -- local variables here
begin
  dbms_output.put_line('插入成功');
end say;
/

