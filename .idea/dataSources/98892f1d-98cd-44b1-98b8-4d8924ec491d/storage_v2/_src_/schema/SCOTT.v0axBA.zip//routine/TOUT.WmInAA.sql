create procedure Tout(eno in number, 
                                 ena out varchar2,
                                 ejob out varchar2) is
begin
  select ename,job into ena,ejob from emp where empno=eno;
end Tout;
/

