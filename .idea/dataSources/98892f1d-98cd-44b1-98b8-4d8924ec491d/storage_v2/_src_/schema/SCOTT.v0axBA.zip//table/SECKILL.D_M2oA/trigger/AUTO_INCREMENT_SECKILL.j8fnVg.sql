create trigger AUTO_INCREMENT_SECKILL
  before insert
  on SECKILL
  for each row
  declare
  -- local variables here
begin
  select SEQ_SECKILL.Nextval into :new.seckill_id from dual;
end auto_increment_seckill;
/

