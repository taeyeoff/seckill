create trigger CHECKTIME
  before insert
  on EMP
  begin
 if to_number(to_char(sysdate,'hh24')) not between 4 and 5
   then 
   
     raise_application_error(-20001,'禁止插入');
     end if;
end checkTime;
/

