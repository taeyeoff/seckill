create package mypacket is

  type empcursor is ref cursor;
  procedure queryEmpList(dno in number,empList out empcursor);
  

  

end mypacket;
/

