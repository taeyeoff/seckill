create package body mypacket is
 procedure queryEmpList(dno in number,empList out empcursor)
 AS
 begin 
   open empList for select * from emp where deptno=dno;
 end queryEmpList;  

 
 
end mypacket;
/

